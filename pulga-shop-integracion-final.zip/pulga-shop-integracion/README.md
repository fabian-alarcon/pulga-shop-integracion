Pulga Shop - Integración Docker

1. Coloca esta carpeta junto a:
   - G4_AuthYRegistro/
   - G7_Inventario/

2. Ajusta los .env según la guía.

3. Ejecuta:
   docker compose build --no-cache
   docker compose up

URLs:
- http://localhost/auth
- http://localhost/inventario
