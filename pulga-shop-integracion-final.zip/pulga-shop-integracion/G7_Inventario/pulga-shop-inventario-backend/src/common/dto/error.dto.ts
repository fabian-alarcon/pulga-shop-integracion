export class ErrorDto {
  message: string;
  error: string;
}
