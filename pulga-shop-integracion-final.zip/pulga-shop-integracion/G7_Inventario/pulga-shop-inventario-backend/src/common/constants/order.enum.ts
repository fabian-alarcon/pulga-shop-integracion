export enum Order {
  ASC = 'asc',
  DESC = 'desc',
}
