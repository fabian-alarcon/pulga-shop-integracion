export interface UserRoles {
  esVendedor: boolean;
  esAdministrador: boolean;
}
