import { getPulgaTheme } from "./theme/get-pulga-theme";

export function printMsg() {
  console.log("This is a message from the demo package");
}

export { getPulgaTheme };
